let Menu = document.querySelector('.Menu');
let Navega = document.querySelector('.Navega');

        Menu.onclick = function() {
            Navega.classList.toggle('active');

        }